<?php

namespace PhpOffice\Math\Exception;

use Exception;

class MathException extends Exception
{
}
