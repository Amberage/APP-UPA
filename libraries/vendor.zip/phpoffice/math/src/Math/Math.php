<?php

namespace PhpOffice\Math;

use PhpOffice\Math\Element\AbstractGroupElement;

class Math extends AbstractGroupElement
{
}
